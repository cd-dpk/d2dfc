package org.dpk.d2dfc.data_models;

public enum Symptoms {
    YES, NO, MAYBE;
}
