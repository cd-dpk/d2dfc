package org.dpk.d2dfc.data_models;


import org.dpk.d2dfc.D2DFC_HANDLER;

public interface IRegistration {
    public void checkRegistration(D2DFC_HANDLER d2DFC_handler);
}
