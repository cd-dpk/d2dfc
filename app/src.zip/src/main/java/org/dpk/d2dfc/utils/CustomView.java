package org.dpk.d2dfc.utils;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.widget.TextView;

import org.dpk.d2dfc.R;
import com.google.android.material.snackbar.Snackbar;

public class CustomView {
/*

    public Snackbar getCustomSnackBar(Context context, View view, String text, int duration){
        // create instance
        Snackbar snackbar = Snackbar.make(view, text, duration);

// set action button color
        snackbar.setActionTextColor(context.getResources().getColor(R.color.indigo));

// get snackbar view
        View snackbarView = snackbar.getView();

// change snackbar text color
        TextView textView = (TextView)snackbarView.findViewById(snackbarTextId);
        textView.setTextColor(getResources().getColor(R.color.indigo));

// change snackbar background
        snackbarView.setBackgroundColor(Color.MAGENTA);
    }*/
}
