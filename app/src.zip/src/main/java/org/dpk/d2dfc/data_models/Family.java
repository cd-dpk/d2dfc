package org.dpk.d2dfc.data_models;

public class Family {
    private String phone;
    private int members;

    public Family(String phone, int members) {
        this.phone = phone;
        this.members = members;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getMembers() {
        return members;
    }

    public void setMembers(int members) {
        this.members = members;
    }
}
