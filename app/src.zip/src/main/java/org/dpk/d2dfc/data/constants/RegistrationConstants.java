package org.dpk.d2dfc.data.constants;

/**
 * Created by chandradasdipok on 4/10/2016.
 */
public class RegistrationConstants {
    public static final String
            APPLICATION_PREFERENCE = "dpk_d2dfc",
            REGISTRATION_STATUS_KEY = "registration",
            REGISTRATION_STATUS_VALUE_COMPLETED = "yes",
            REGISTRATION_STATUS_VALUE_NOT_COMPLETED = "no",
            REPORTER_PHONE_KEY="phone",
            REPORTER_NAME_KEY="name",
            COMPLEX_VALUE="-i";
    public static String
            REGISTRATION_STATUS_VALUE=COMPLEX_VALUE,
            REPORTER_PHONE=COMPLEX_VALUE,
            REPORTER_NAME=COMPLEX_VALUE;
}
