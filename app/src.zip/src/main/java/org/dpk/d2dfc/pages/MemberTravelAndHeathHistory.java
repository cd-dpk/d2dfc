package org.dpk.d2dfc.pages;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import org.dpk.d2dfc.R;

public class MemberTravelAndHeathHistory extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_member_travel_and_heath_history);
    }
}
