package org.dpk.d2dfc.data_models;

import android.view.View;

public interface OnRecyclerViewItemListener {
    public void listenItem(View view, int position);
}
