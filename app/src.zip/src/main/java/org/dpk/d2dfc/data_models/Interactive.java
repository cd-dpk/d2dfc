package org.dpk.d2dfc.data_models;

public interface Interactive {
    public void findView();
}
