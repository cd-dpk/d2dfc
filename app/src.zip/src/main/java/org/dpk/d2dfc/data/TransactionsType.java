package org.dpk.d2dfc.data;

public enum TransactionsType {
    GIVEN, TAKEN;
}
