package org.dpk.d2dfc.data_models;

public class PersonBasicInfo {

    private String mobile, name, gender, father, mother, birthdate, age;
    private String personID;

    public PersonBasicInfo(String mobile, String name) {
        this.mobile = mobile;
        this.name = name;
        personID = name+mobile;
    }

    public String getPersonID(){
        return personID;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setFather(String father) {
        this.father = father;
    }

    public void setMother(String mother) {
        this.mother = mother;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    public void setAge(String age) {
        this.age = age;
    }
}
